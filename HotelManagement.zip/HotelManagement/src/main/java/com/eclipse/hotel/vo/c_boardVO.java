package com.eclipse.hotel.vo;

public class c_boardVO {
	int b_num;
	int c_num;
	String memo;
	String registerdate;
	
	public int getB_num() {
		return b_num;
	}
	public int getC_num() {
		return c_num;
	}
	public String getMemo() {
		return memo;
	}
	public String getRegisterdate() {
		return registerdate;
	}
	public void setB_num(int b_num) {
		this.b_num = b_num;
	}
	public void setC_num(int c_num) {
		this.c_num = c_num;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
	public void setRegisterdate(String registerdate) {
		this.registerdate = registerdate;
	}
	
}
