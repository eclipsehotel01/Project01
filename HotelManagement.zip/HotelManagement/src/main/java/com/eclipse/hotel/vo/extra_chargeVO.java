package com.eclipse.hotel.vo;

public class extra_chargeVO {
	String extracode;
	String e_name;
	int e_price;
	
	public String getExtracode() {
		return extracode;
	}
	public void setExtracode(String extracode) {
		this.extracode = extracode;
	}
	public String getE_name() {
		return e_name;
	}
	public void setE_name(String e_name) {
		this.e_name = e_name;
	}
	public int getE_price() {
		return e_price;
	}
	public void setE_price(int e_price) {
		this.e_price = e_price;
	}
	
	
}
