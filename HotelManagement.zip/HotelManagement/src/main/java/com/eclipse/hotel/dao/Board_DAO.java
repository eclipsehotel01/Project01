package com.eclipse.hotel.dao;

import org.springframework.stereotype.Repository;

@Repository("board_dao")
public class Board_DAO {

}
