package com.eclipse.hotel.dao;

import org.springframework.stereotype.Repository;

@Repository("member_dao")
public class Member_DAO {

}
