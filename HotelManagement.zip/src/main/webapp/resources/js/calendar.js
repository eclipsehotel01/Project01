//달력 생성
$(document).ready(function() {
	alert("<c:out value=${jarr}/>");

	
	/*$.ajax({
		type : "GET",
		url : "admin_reserve_list",
		dataType : "json",
		success : function(data){
			alert(data);
		}
	})*/
	
	
    $('#content_calendar').fullCalendar({
    	header : {    		
    		left : 'title',
    		right : 'today prev, next'
    	}
    	
    })
});
