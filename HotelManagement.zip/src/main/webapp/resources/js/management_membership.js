//수정버튼
function btnUpdate(m_num){
	alert(m_num);
	location.href = "admin_membership_update?m_num="+m_num;	
}