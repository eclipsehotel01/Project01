!function(e) {
	"function" == typeof define && define.amd ? define([ "jquery", "moment" ],
			e) : "object" == typeof exports ? module.exports = e(
			require("jquery"), require("moment")) : e(jQuery, moment)
}(function(e, t) {
	!function() {
		var e = t.defineLocale("ko", {
			months : "1월_2월_3월_4월_5월_6월_7월_8월_9월_10월_11월_12월".split("_"),
			monthsShort : "1월_2월_3월_4월_5월_6월_7월_8월_9월_10월_11월_12월".split("_"),
			weekdays : "일요일_월요일_화요일_수요일_목요일_금요일_토요일".split("_"),
			weekdaysShort : "일_월_화_수_목_금_토".split("_"),
			weekdaysMin : "일_월_화_수_목_금_토".split("_"),
			longDateFormat : {
				LT : "A h시 m분",
				LTS : "A h시 m분 s초",
				L : "YYYY.MM.DD",
				LL : "YYYY년 MMMM D일",
				LLL : "YYYY년 MMMM D일 A h시 m분",
				LLLL : "YYYY년 MMMM D일 dddd A h시 m분"
			},
			calendar : {
				sameDay : "오늘 LT",
				nextDay : "내일 LT",
				nextWeek : "dddd LT",
				lastDay : "어제 LT",
				lastWeek : "지난주 dddd LT",
				sameElse : "L"
			},
			relativeTime : {
				future : "%s 후",
				past : "%s 전",
				s : "몇 초",
				ss : "%d초",
				m : "일분",
				mm : "%d분",
				h : "한 시간",
				hh : "%d시간",
				d : "하루",
				dd : "%d일",
				M : "한 달",
				MM : "%d달",
				y : "일 년",
				yy : "%d년"
			},
			ordinalParse : /\d{1,2}일/,
			ordinal : "%d일",
			meridiemParse : /오전|오후/,
			isPM : function(e) {
				return "오후" === e
			},
			meridiem : function(e, t, a) {
				return e < 12 ? "오전" : "오후"
			}
		});
		return e
	}(), e.fullCalendar.datepickerLocale("ko", "ko", {
		closeText : "닫기",
		prevText : "이전달",
		nextText : "다음달",
		currentText : "오늘",
		monthNames : [ "1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월",
				"10월", "11월", "12월" ],
		monthNamesShort : [ "1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월",
				"9월", "10월", "11월", "12월" ],
		dayNames : [ "일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일" ],
		dayNamesShort : [ "일", "월", "화", "수", "목", "금", "토" ],
		dayNamesMin : [ "일", "월", "화", "수", "목", "금", "토" ],
		weekHeader : "주",
		dateFormat : "yy. m. d.",
		firstDay : 0,
		isRTL : !1,
		showMonthAfterYear : !0,
		yearSuffix : "년"
	}), e.fullCalendar.locale("ko", {
		buttonText : {
			month : "월",
			week : "주",
			day : "일",
			list : "일정목록"
		},
		allDayText : "종일",
		eventLimitText : "개",
		noEventsMessage : "일정이 표시 없습니다"
	})
});