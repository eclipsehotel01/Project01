package com.eclipse.hotel.admin.controller;

import java.util.List;

import javax.annotation.Resource;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.eclipse.hotel.admin.service.Reserve_Service;
import com.eclipse.hotel.vo.room_reserveVO;

@Controller
public class Reserve_Controller {

	@Resource(name = "reserve_service")
	private Reserve_Service reserve_service;
	
	//���� ����
	@RequestMapping(value = "admin_reserve_list", method = RequestMethod.GET)
	public String list(Model model){		
		List<room_reserveVO> reserveList = reserve_service.list();			
		
		//parsing(json)
		JSONArray jarr = new JSONArray();
		JSONObject obj = null;
		for(room_reserveVO r : reserveList){
			obj = new JSONObject();
			try {
				obj.put("reservecode", r.getReservecode());
				obj.put("m_num", r.getM_num());
				obj.put("check_in", r.getCheck_in());
				obj.put("check_out", r.getCheck_out());
				obj.put("p_price", r.getP_price());
				jarr.put(obj);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}	
		
		model.addAttribute("jarr", jarr);
		
		return "management/reserve/room_reserve_calendar";
	}
}
