package com.eclipse.hotel.guest.controller;

import javax.annotation.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.beans.factory.annotation.Autowired;

import com.eclipse.hotel.admin.service.Board_Service;
import com.eclipse.hotel.guest.service.Board_Guest_Service;
import com.eclipse.hotel.util.PageAction;

@Controller
public class Board_Guest_Controller {
	
	@Resource(name = "board_guest_service")
	private Board_Guest_Service board_guest_service;
	@Autowired
	
	PageAction pageaction;
	
	@RequestMapping("memberLogin")
	private String login(){
		return "guest/board/guestboardinsert1";
	}
}
