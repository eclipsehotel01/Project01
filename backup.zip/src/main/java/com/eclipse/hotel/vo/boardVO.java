package com.eclipse.hotel.vo;

public class boardVO {
	int b_num;
	int m_num;
	String id;
	String name;
	String category;
	String title;
	String password;
	String content;
	int count;
	String registerdate;
	int groups;
	int levels;
	int steps;
	int c_num;
	String memo;
	
	public int getC_num() {
		return c_num;
	}
	public String getMemo() {
		return memo;
	}
	public int getB_num() {
		return b_num;
	}
	public int getM_num() {
		return m_num;
	}
	public String getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public String getCategory() {
		return category;
	}
	public String getTitle() {
		return title;
	}
	public String getPassword() {
		return password;
	}
	public String getContent() {
		return content;
	}
	public int getCount() {
		return count;
	}
	public String getRegisterdate() {
		return registerdate;
	}
	
	public int getGroups() {
		return groups;
	}
	public int getLevels() {
		return levels;
	}
	public int getSteps() {
		return steps;
	}
	public void setB_num(int b_num) {
		this.b_num = b_num;
	}

	public void setC_num(int c_num) {
		this.c_num = c_num;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}

	public void setM_num(int m_num) {
		this.m_num = m_num;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public void setRegisterdate(String registerdate) {
		this.registerdate = registerdate;
	}
	public void setGroups(int groups) {
		this.groups = groups;
	}
	public void setLevels(int levels) {
		this.levels = levels;
	}
	public void setSteps(int steps) {
		this.steps = steps;
	}
	
}
