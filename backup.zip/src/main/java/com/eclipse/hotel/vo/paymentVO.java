package com.eclipse.hotel.vo;

public class paymentVO {
	
	int p_num;
	int reservecode;
	String p_date;
	int p_price;
	
	public int getP_num() {
		return p_num;
	}
	public void setP_num(int p_num) {
		this.p_num = p_num;
	}
	public int getReservecode() {
		return reservecode;
	}
	public void setReservecode(int reservecode) {
		this.reservecode = reservecode;
	}
	public String getP_date() {
		return p_date;
	}
	public void setP_date(String p_date) {
		this.p_date = p_date;
	}
	public int getP_price() {
		return p_price;
	}
	public void setP_price(int p_price) {
		this.p_price = p_price;
	}
	
	

}
